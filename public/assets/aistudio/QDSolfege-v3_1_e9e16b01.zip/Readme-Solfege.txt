Copy "Solfege.xml" to your own "Instruments" folder.
Open the Musescore software, select Preferences from the Edit menu 
and select Score Tab from the pop-up window.
Enter the file path of "Solfege.xml" from "Insrument list 2".

or

For advanced users only:
Close the Musescore software.
Open the file "Solfege.xml" in a text editor, 
copy it from the marked places, 
and paste it at the end of the original "Instruments.xml" file. 
And save the file.
Open Musescore software.

-----------------------------

Usage:

For special bemol/flat and/or diese/sharps:
Click on the note.
Add Staff-Text with Ctrl + T.
Right-click the text you just added and select Staff-text properties.
Select the one that matches the situation in the boxes. (and voices)

Caution: 
The "Diese/sharp and/or bemol/flat" change you last entered remains valid. 
You must enter a new one to restore it.
By default: Select diese/sharp.

Open the "QDSolfege_test-#b.mscz" file in Musescore and examine the usage of staff text.
